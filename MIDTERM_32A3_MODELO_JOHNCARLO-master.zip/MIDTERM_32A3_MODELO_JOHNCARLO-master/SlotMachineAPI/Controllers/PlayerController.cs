﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SlotMachineAPI.DTO;
using SlotMachineAPI.Models;

[Route("api/[controller]")]
[ApiController]
public class PlayersController : ControllerBase
{
	private readonly SlotMachineDbContext _context;

	public PlayersController(SlotMachineDbContext context)
	{
		_context = context;
	}

	[HttpPost("validate")]
	public async Task<IActionResult> ValidatePlayerLogin([FromBody] PlayerLoginDTO playerLogin)
	{
		var player = await _context.Players.FirstOrDefaultAsync(p => p.StudentNumber == playerLogin.StudentNumber);

		if (player == null)
		{
			return NotFound("Player not found.");
		}

		var gameResult = await _context.GameResults.FirstOrDefaultAsync(gr => gr.PlayerId == player.PlayerId);

		if (gameResult == null)
		{
			// Create a new game result for the player
			gameResult = new GameResult
			{
				PlayerId = player.PlayerId,
				Outcome = "Loss", // Default outcome
				Tries = 0,
				DatePlayed = DateTime.Now
			};

			await _context.GameResults.AddAsync(gameResult);
			await _context.SaveChangesAsync();
		}

		// Check if player has cooldown
		if (player.CooldownDate.HasValue && DateTime.Now < player.CooldownDate.Value)
		{
			return Ok(new { exists = true, cooldown = player.CooldownDate });
		}

		return Ok(new { exists = true, cooldown = (DateTime?)null });
	}
}

public class ValidatePlayerRequest
{
	public string StudentNumber { get; set; }
}
