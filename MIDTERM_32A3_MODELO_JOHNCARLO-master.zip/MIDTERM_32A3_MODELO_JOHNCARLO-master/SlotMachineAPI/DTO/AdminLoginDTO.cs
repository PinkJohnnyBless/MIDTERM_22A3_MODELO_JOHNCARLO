﻿using System.ComponentModel.DataAnnotations;
namespace SlotMachineAPI.DTO
{
	public class AdminLoginDto
	{
		[Required]
		public string Username { get; set; } = string.Empty;

		[Required]
		public string Password { get; set; } = string.Empty;
	}

}
