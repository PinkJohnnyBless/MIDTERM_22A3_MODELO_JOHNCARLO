﻿using System.ComponentModel.DataAnnotations;

namespace SlotMachineAPI.Models
{
	public class GameResult
	{
		public int GameResultId { get; set; } // Primary key

		public int PlayerId { get; set; } // Foreign key to Player
		public Player Player { get; set; } = default!; // Navigation property to Player

		public string Outcome { get; set; } = string.Empty; // Outcome of the game (Win or Loss)

		public int Tries { get; set; } // Number of tries the player had

		public DateTime DatePlayed { get; set; } = DateTime.Now; // Date the game result was recorded
	}
}
